
public interface myInterface {
	
	
public int newInterface(int a, int b);


	
	
	
	

	

}
