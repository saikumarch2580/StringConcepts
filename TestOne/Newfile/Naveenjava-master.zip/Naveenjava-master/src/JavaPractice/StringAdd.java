package JavaPractice;

public class StringAdd {
	


	public static void main(String[] args) {
		
		String str = "Java, Selenium, Testng, Automation";
		String str2[]= str.split(",");
	
		System.out.println(str2[1]);
			
		}
	
		
		
		
							
				
	

}
