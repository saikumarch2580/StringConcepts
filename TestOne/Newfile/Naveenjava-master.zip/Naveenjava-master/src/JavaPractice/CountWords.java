package JavaPractice;

public class CountWords {

	public static void main(String[] args) {
		
		String sa = "sairam";
		int count =0;
		int len = sa.length();
		
		
		
		for(int i=0; i<len; i++) {
			count++;
		 
			System.out.println(count);
			
		}

	}

}
