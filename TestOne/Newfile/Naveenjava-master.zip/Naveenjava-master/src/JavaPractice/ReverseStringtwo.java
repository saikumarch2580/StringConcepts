package JavaPractice;

public class ReverseStringtwo {

	public static void main(String[] args) {
	
		String str ="SAIRAM";
		
		StringBuffer bf = new StringBuffer(str);
      StringBuffer s2 = bf.reverse();
        System.out.println(s2);
	}
}
