package JavaPractice;

public class StringConvert {

	public static void main(String[] args) {
		
		String str = "235";
		int a = 19;
	int num =Integer.parseInt(str);
	System.out.println(str);
	System.out.println(num+a);
	
	String s = String.valueOf(a);
	System.out.println(s);
	System.out.println(s+a);
	

	}

}
