package Accessmodifiertest;

import accessmodifiers.NewProtected;

public class Accessmodifiertest1 extends NewProtected {

	//public static void main(String[] args) {
//		NewProtected d = new NewProtected();
//		d.mynumber();
   public void newstring() {
	   
	   mynumber();
   
	   
   }
	}

