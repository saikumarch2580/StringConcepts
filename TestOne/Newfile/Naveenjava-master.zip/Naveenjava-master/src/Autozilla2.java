
public class Autozilla2 {

	public static void main(String[] args) {

		calculation actualvalue = new calculation();
		int value1 = actualvalue.addition();
		int value2 = actualvalue.subtraction();
		System.out.println(value1);
		System.out.println(value2);

	}

}
