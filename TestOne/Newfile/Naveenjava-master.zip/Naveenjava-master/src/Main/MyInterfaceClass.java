package Main;

public class MyInterfaceClass implements MyInterface {

	 public static void calculation() {
	        System.out.println("Sairam chintha");
	 }

	    public static void main(String[] args) {
//	        MyInterface ad = new Addition(); // Use the interface type to reference the object
	        calculation();
	    }
}
