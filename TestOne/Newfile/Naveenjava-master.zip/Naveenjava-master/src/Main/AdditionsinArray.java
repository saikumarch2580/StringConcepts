package Main;

public class AdditionsinArray {

	public static void main(String[] args) {
		
		int num[] = {1,3,4,6,7,8,50};

		int sum =0;
		
		for(int i=0; i<num.length; i++) {
			
			sum = sum + num[i];
			
			 
		}
	System.out.println(sum);
	}

 
}
