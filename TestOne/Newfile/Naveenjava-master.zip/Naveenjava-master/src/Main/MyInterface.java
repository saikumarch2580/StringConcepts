package Main;

public interface MyInterface {
	
	public static void calculation() {
		
	}
	
}
