package Main;

public class NameSai {

	public static void main(String[] args) {
		
		String Name = "Sairam";
		int j = 0;
		for(int i =0; i<j; i++);
		System.out.println(j);
		
		

	}
	
  
	StringBuilder str = new StringBuilder();

}
	
	

