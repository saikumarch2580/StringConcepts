package Main;



public class AddnewArray {

	public static void main(String[] args) {
		
		int[] arr = {4,5,3,24,23};
		
        int add = 44;
        
        
        for(int i=5; i<arr.length; i++) {
        	
        	
        	System.out.println(arr[i]);
        	
        }
	}
	
	

}
