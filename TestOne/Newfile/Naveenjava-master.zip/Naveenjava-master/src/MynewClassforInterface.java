
public class MynewClassforInterface implements myInterface{

	public static void main(String[] args) {
		
		
		

	}

	@Override
	public int newInterface(int c, int d) {
		int a=10;
		int b= 20;
		return c+d;
		
		
	}

}
