package NaveenJava;

public class HDFCBank extends Bank{

	public static void main(String[] args) {
		

	}

	@Override
	public void HdfcBank() {
		System.out.println("This is HDFC BANK");
		
	}
  public void regonalBank() {
	  System.out.println("this is regional bank");
	  
  }
}
