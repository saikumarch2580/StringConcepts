package NaveenJava;

import java.util.Scanner;

public class AlphabetorNot {

	

	public static void main(String[] args) {
    System.out.println("Enter number is :"  );
		Scanner sc = new Scanner(System.in);
		char EnterValue = sc.next().charAt(0);
				
		if(EnterValue<='Z') {
			
			System.out.println("enter value is alphabet");
		}else{
			
			System.out.println("enter value is NUMBER");
			
			
		}
		
		
		
	
			
			
		}
		
		
	

}
