package NaveenJava;

public abstract class Bank {
	
	public abstract void HdfcBank();
	
	public void IciciBank() {
		
		System.out.println("This is ICICI Bank");
	}
	
	public void SBIBank() {
		
		System.out.println("This is SBI BANK");
	}
	

}
