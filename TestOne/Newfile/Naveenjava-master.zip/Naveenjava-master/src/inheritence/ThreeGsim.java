package inheritence;

public class ThreeGsim extends TwoGsim{
	
	public void calling(){
		
		System.out.println("Calling, Messaging");
		

	}
 public void gprs() {
	 
	 
	 System.out.println("Calling+Message+gprs");
	 
 }
}
