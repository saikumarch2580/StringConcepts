package inheritence;

public class TwoGThreeGFourG {

	public static void main(String[] args) {
		TwoGsim Two = new TwoGsim();
		Two.calling();
		
		
		 
		FourGsim four = new FourGsim();
		four.calling();
		four.camera();
		four.gprs();
		
		

	}

}
