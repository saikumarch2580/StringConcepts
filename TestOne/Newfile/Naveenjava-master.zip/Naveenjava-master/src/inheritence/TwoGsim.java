package inheritence;

public class TwoGsim{
	
	public void calling() {
		
		System.out.println("Calling, Message");
	}
	
	
	
	
	
	
	

}