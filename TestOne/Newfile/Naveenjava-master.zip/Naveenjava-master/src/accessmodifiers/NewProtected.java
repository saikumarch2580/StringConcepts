package accessmodifiers;

public class NewProtected {

	
 protected int a = 10;
 
 protected void mynumber() {
	 
	 System.out.println("correct");
	 
 }
	
	
	
	
	
	
	
	}


