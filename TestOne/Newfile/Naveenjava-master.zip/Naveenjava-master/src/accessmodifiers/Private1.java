package accessmodifiers;



public class Private1 {
	
	private int finalnumber =10;

	public void modifier(int a) {
		 
		finalnumber=a;
		
	}
	
public int getfinalnumber() {
	
	return finalnumber;
}
	
}
 