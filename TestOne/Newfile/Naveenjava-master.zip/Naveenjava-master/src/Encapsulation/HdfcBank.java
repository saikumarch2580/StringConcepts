
package Encapsulation;

public class HdfcBank{
	
	private String name="sairam";
	
	public String GetName() {
		System.out.println("Accessing your name");
		return name;
	}
		
public void SetName(String name) {
	System.out.println("Your name is changed");
	this.name=name;
	
	
	
	
	
	
}
		
		
		
	

}