package Encapsulation;

public class GooglePay {

	public static void main(String[] args) {
		HdfcBank bank = new HdfcBank();
		bank.SetName("LAKSHMI KANTHI");
		System.out.println(bank.GetName());
		

	}

}
