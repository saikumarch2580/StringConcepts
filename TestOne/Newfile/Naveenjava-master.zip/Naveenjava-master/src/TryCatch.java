
public class TryCatch {

	public static void main(String[] args) {
				  
			  int a = 10;
			  int b= 5;	  			  
			  try{			    
			    boolean c=a<b;			    
			  } catch(Exception e) {
			  System.out.println("the try was wrong");
			  boolean c=a>b;		  
			}			  
			  System.out.println("Correct");
	}
	}


